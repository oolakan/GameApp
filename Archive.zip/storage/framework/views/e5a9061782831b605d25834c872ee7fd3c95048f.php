<div class="modal fade" id="edit-<?php echo e($game->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-user"></i>MODIFY GAME INFORMATION</h4>
            </div>
            <form action="<?php echo e(url('/game/update/'.base64_encode($game->id))); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <table class="table table-stripped">
                        <input type="hidden" name="users_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                        <tr>
                            <th width="40%">Game Name</th>
                            <td>
                                <select name="game_names_id" required="" class="form-control">
                                    <option value="">Select Game Name</option>
                                    <?php $__currentLoopData = $GameNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gameName->id); ?>" <?php if($gameName->id == $game->game_name->id): ?> selected <?php endif; ?>><?php echo e($gameName->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th width="40%">Game Type</th>
                            <td>
                                <select name="game_types_id" required="" class="form-control">
                                    <option value="">Select Game Type</option>
                                    <?php $__currentLoopData = $GameTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gameType->id); ?>" <?php if($gameType->id == $game->game_type->id): ?> selected <?php endif; ?>><?php echo e($gameType->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </td>
                        </tr>


                        <tr>
                            <th width="40%">Game Type Option</th>
                            <td>
                                <select name="game_type_options_id" required="" class="form-control">
                                    <option value="">Select Game Type Option</option>
                                    <?php $__currentLoopData = $GameTypeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameTypeOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gameTypeOption->id); ?>" <?php if($gameTypeOption->id == $game->game_type_option->id): ?> selected <?php endif; ?>><?php echo e($gameTypeOption->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </td>
                        </tr>

                        <tr>
                            <th width="40%">Game Quater</th>
                            <td>
                                <select name="game_quaters_id" required="" class="form-control">
                                    <option value="">Select Game Quater</option>
                                    <?php $__currentLoopData = $GameQuaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameQuater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gameQuater->id); ?>" <?php if($gameQuater->id == $game->game_quater->id): ?> selected <?php endif; ?>><?php echo e($gameQuater->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </td>
                        </tr>

                        <tr>
                            <th>Start Time</th>
                            <td><input type="text" name="start_time" value="<?php echo e($game->start_time); ?>" placeholder="Start Time" class="form-control"> </td>
                        </tr>

                        <tr>
                            <th>Stop Time</th>
                            <td><input type="text" name="stop_time" value="<?php echo e($game->stop_time); ?>" placeholder="Stop Time" class="form-control"> </td>
                        </tr>

                        <tr>
                            <th>Game Status</th>
                            <td>
                                <select name = "game_status" class="form-control">
                                    <option value="0" <?php if( $game->game_status == 0): ?> selected <?php endif; ?>>OPENED</option>
                                    <option value="1"  <?php if( $game->game_status == 1): ?> selected <?php endif; ?>>CLOSED</option>
                                </select>
                            </td>
                        </tr>


                    </table>
                    <div class="modal-footer clearfix">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-book"></i> Update </button>
                        <button type="button" class="btn btn-danger pull-left" data-dismiss="modal"><i class="fa fa-times"></i>Close</button>
                    </div>
                </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->