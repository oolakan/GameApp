<div class="modal fade" id="add-new-game" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><i class="fa fa-book"></i>ADD NEW GAME INFORMATION</h4>
            </div>
            <form action="<?php echo e(url('/winning/store')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <table class="table table-stripped">
                        <input type="hidden" name="users_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                        <tr>
                            <th>Game No.</th>
                            <td><input type="text" name="game_no" value="<?php echo e(old('game_no')); ?>" placeholder="Gamae no." class="form-control"> </td>
                        </tr>

                        <tr>
                            <th>Winning Date</th>
                            <td><input type="text" name="winning_date" value="<?php echo e(old('winning_date')); ?>" placeholder="Winning Date" class="form-control"> </td>
                        </tr>

                        <tr>
                            <th>Winning Time</th>
                            <td><input type="text" name="winning_time" value="<?php echo e(old('winning_time')); ?>" placeholder="Winning Time" class="form-control"> </td>
                        </tr>

                        <tr>
                            <th width="40%">Game Name</th>
                            <td>
                                    <select name="game_names_id" required="" class="form-control">
                                        <option value="">Select Game Name</option>
                                        <?php $__currentLoopData = $GameNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($gameName->id); ?>"><?php echo e($gameName->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                             </td>
                        </tr>

                        <tr>
                            <th width="40%">Game Type</th>
                            <td>
                                <select name="game_types_id" required="" class="form-control">
                                    <option value="">Select Game Type</option>
                                    <?php $__currentLoopData = $GameTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gameType->id); ?>"><?php echo e($gameType->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </td>
                        </tr>


                        <tr>
                            <th width="40%">Game Type Option</th>
                            <td>
                                <select name="game_type_options_id" required="" class="form-control">
                                    <option value="">Select Game Type Option</option>
                                    <?php $__currentLoopData = $GameTypeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameTypeOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gameTypeOption->id); ?>"><?php echo e($gameTypeOption->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </td>
                        </tr>

                        <tr>
                            <th width="40%">Game Quater</th>
                            <td>
                                <select name="game_quaters_id" required="" class="form-control">
                                    <option value="">Select Game Quater</option>
                                    <?php $__currentLoopData = $GameQuaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameQuater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($gameQuater->id); ?>"><?php echo e($gameQuater->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </td>
                        </tr>

                    </table>
                    <div class="modal-footer clearfix">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-book"></i>Submit</button>
                        <button type="button" class="btn btn-danger pull-left" data-dismiss="modal"><i class="fa fa-times"></i>Close</button>
                    </div>
                </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->